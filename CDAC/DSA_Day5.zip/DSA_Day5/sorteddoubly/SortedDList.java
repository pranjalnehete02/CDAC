package com.cdac.acts.sorteddoubly;

public interface SortedDList {
	public void insert(int element);
	public void delete(int element);
	public void deleteAll(int element);
	public  boolean search(int element);
	public void print();
}
