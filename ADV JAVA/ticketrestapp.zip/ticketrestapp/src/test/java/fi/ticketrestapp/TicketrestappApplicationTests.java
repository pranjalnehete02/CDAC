package fi.ticketrestapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TicketrestappApplicationTests {

	@Test
	void contextLoads() {
	}

}
