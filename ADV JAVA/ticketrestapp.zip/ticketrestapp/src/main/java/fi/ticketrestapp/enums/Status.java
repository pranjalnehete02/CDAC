package fi.ticketrestapp.enums;

public enum Status {

	OPEN,
	IN_PROGRESS,
	RESOLVED
}
