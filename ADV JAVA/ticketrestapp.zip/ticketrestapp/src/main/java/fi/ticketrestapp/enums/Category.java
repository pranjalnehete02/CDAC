package fi.ticketrestapp.enums;

public enum Category {

	SIM,
	CALLING,
	BROADBAND
}
