package com.cdac.publicdrive;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PublicdriveApplication {

	public static void main(String[] args) {
		SpringApplication.run(PublicdriveApplication.class, args);
	}

}
